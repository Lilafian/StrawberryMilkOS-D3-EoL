=========================SMOS=D3============================
Welcome to SMOS, build Developer 3.
Double-click "setup.bat" to setup SMOS.
============================================================
SMOS D3
0.6.1

Simplicity at its finest.
Strawberry Milk OS.

README document for SMOS Development 3
Last updated:
2:23 PM 5/23/2022